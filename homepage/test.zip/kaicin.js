// let toggle = document.querySelector(".toggle");
// let navigation = document.querySelector(".navigation");
// let main = document.querySelector(".main");

// toggle.onclick = function () {
//   navigation.classList.toggle("active");
//   main.classList.toggle("active");
// };

// // ==========================================
// // Dynamic Medical Form Submission Logic
// // ==========================================

// const recordForm = document.getElementById("recordForm");
// const recordTableBody = document.getElementById("recordTableBody");

// recordForm.addEventListener("submit", function(event) {
//     // Prevent the form from reloading the page
//     event.preventDefault(); 

//     // 1. Get the values the user typed in
//     const nameValue = document.getElementById("patientName").value;
//     const typeValue = document.getElementById("reportType").value;
//     const ambValue = document.getElementById("ambulanceStatus").value;
//     const statusValue = document.getElementById("patientStatus").value;

//     // 2. Format the status text to match the medical theme
//     let statusText = "";
//     if(statusValue === "delivered") statusText = "Discharged";
//     if(statusValue === "pending") statusText = "Admitted";
//     if(statusValue === "return") statusText = "Critical";
//     if(statusValue === "inProgress") statusText = "Stable";

//     // 3. Create a brand new table row element
//     const newRow = document.createElement("tr");

//     // 4. Inject the HTML into the new row for the 4 medical columns
//     newRow.innerHTML = `
//         <td>${nameValue}</td>
//         <td>${typeValue}</td>
//         <td>${ambValue}</td>
//         <td><span class="status ${statusValue}">${statusText}</span></td>
//     `;

//     // 5. Add the new row to the bottom of the table
//     recordTableBody.appendChild(newRow);

//     // 6. Clear out the form so it's ready for the next entry
//     recordForm.reset();
// });
// function resetDatabase() {
//     if (confirm("Are you sure you want to delete all registered accounts?")) {
//         localStorage.removeItem('medical_users');
//         alert("Database cleared! Redirecting to login...");
//         window.location.href = "login.html";
//     }
// }
// // --- Updated Form Submission Logic ---
// recordForm.addEventListener("submit", function(event) {
//     event.preventDefault(); 

//     const nameValue = document.getElementById("patientName").value;
//     const typeValue = document.getElementById("reportType").value;
//     const ambValue = document.getElementById("ambulanceStatus").value;
//     const statusValue = document.getElementById("patientStatus").value;

//     let statusText = "";
//     if(statusValue === "delivered") statusText = "Discharged";
//     if(statusValue === "pending") statusText = "Admitted";
//     if(statusValue === "return") statusText = "Critical";
//     if(statusValue === "inProgress") statusText = "Stable";

//     const newRow = document.createElement("tr");

//     // Added a 5th column <td> with a Delete button
//     newRow.innerHTML = `
//         <td>${nameValue}</td>
//         <td>${typeValue}</td>
//         <td>${ambValue}</td>
//         <td><span class="status ${statusValue}">${statusText}</span></td>
//         <td>
//             <button class="delete-row-btn" onclick="removeRow(this)">
//                 <ion-icon name="trash-outline"></ion-icon>
//             </button>
//         </td>
//     `;

//     recordTableBody.appendChild(newRow);
//     recordForm.reset(); // Clears the form inputs after adding
// });

// // --- New Function: Remove Single Row ---
// function removeRow(button) {
//     // 'button' is inside a <td>, which is inside a <tr>
//     const row = button.closest("tr");
//     row.remove();
// }

// // --- New Function: Clear All Rows ---
// function clearAllRows() {
//     if (confirm("Are you sure you want to delete ALL medical reports?")) {
//         const tableBody = document.getElementById("recordTableBody");
//         tableBody.innerHTML = ""; // Removes all HTML inside the tbody
//     }
// }
let toggle = document.querySelector(".toggle");
let navigation = document.querySelector(".navigation");
let main = document.querySelector(".main");

toggle.onclick = function () {
  navigation.classList.toggle("active");
  main.classList.toggle("active");
};

// ==========================================
// Dynamic Medical Form Submission Logic
// ==========================================

const recordForm = document.getElementById("recordForm");
const recordTableBody = document.getElementById("recordTableBody");

// Safety check: Only attach the event listener if the form exists on the page
if (recordForm) {
    recordForm.addEventListener("submit", function(event) {
        // Prevent the form from reloading the page
        event.preventDefault(); 

        // 1. Get the values the user typed in
        const nameValue = document.getElementById("patientName").value;
        const typeValue = document.getElementById("reportType").value;
        const ambValue = document.getElementById("ambulanceStatus").value;
        const statusValue = document.getElementById("patientStatus").value;

        // 2. Format the status text to match the medical theme
        let statusText = "";
        if(statusValue === "delivered") statusText = "Discharged";
        if(statusValue === "pending") statusText = "Admitted";
        if(statusValue === "return") statusText = "Critical";
        if(statusValue === "inProgress") statusText = "Stable";

        // 3. Create a brand new table row element
        const newRow = document.createElement("tr");

        // 4. Inject the HTML into the new row for the 5 columns (including Delete button)
        newRow.innerHTML = `
            <td>${nameValue}</td>
            <td>${typeValue}</td>
            <td>${ambValue}</td>
            <td><span class="status ${statusValue}">${statusText}</span></td>
            <td>
                <button class="delete-row-btn" onclick="removeRow(this)">
                    <ion-icon name="trash-outline"></ion-icon>
                </button>
            </td>
        `;

        // 5. Add the new row to the bottom of the table
        recordTableBody.appendChild(newRow);

        // 6. Clear out the form so it's ready for the next entry
        recordForm.reset(); 
    });
}

function resetDatabase() {
    if (confirm("Are you sure you want to delete all registered accounts?")) {
        localStorage.removeItem('medical_users');
        alert("Database cleared! Redirecting to login...");
        window.location.href = "/comp/login/login.html";
    }
}

// --- New Function: Remove Single Row ---
function removeRow(button) {
    // 'button' is inside a <td>, which is inside a <tr>
    const row = button.closest("tr");
    row.remove();
}

// --- New Function: Clear All Rows ---
function clearAllRows() {
    if (confirm("Are you sure you want to delete ALL medical reports?")) {
        const tableBody = document.getElementById("recordTableBody");
        if (tableBody) {
            tableBody.innerHTML = ""; // Removes all HTML inside the tbody
        }
    }
}
// ==========================================
// Sidebar Dropdown Logic
// ==========================================
const dropdownBtn = document.querySelector(".dropdown-btn");
const dropdownParent = document.querySelector(".dropdown");

if (dropdownBtn) {
    dropdownBtn.addEventListener("click", function(event) {
        event.preventDefault(); // Prevents the page from jumping to the top
        dropdownParent.classList.toggle("active");
    });
}